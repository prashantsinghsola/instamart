

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EditedProfile
 */
@WebServlet("/EditedProfile")
public class EditedProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	java.sql.Statement st;
    private static final String URL = "jdbc:mysql://localhost:3306/Instamart";
    private static final String USER = "root";
    private static final String PASSWORD = "om61,,..";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditedProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("index.jsp");  // Redirect to login if session expires
            return;
        }

        String username = (String) session.getAttribute("username");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String dob = request.getParameter("dob");
        String age = request.getParameter("age");
        String contact = request.getParameter("contact");
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String country = request.getParameter("country");
        String pinCode = request.getParameter("pinCode");

        

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection(URL,USER,PASSWORD);

            // Update user details query
            String sql = "UPDATE users SET dob=?, age=?, contact=?, street=?, city=?, state=?, country=?, pinCode=? WHERE username=?";
            pstmt = conn.prepareStatement(sql);

            // Set values to the query
            pstmt.setString(1, dob);
            pstmt.setString(2, age);
            pstmt.setString(3, contact);
            pstmt.setString(4, street);
            pstmt.setString(5, city);
            pstmt.setString(6, state);
            pstmt.setString(7, country);
            pstmt.setString(8, pinCode);
            pstmt.setString(9, username);

            // Execute update query
            int rowsUpdated = pstmt.executeUpdate();

            if (rowsUpdated > 0) {
                // Successfully updated, redirect back to profile page
                response.sendRedirect("Profile");
            } else {
                // No rows updated (invalid username)
                response.sendRedirect("Profile");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("Profile.jsp?error=2");  // Redirect with error flag
        } finally {
            // Close resources
            try { if (pstmt != null) pstmt.close(); } catch (Exception ignored) {}
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
	
	}

}
