import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Cart")
public class Cart extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public Cart() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        if (username == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        List<String> cartItems = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Instamart", "root", "om61,,..");

            String query = "SELECT * FROM cart WHERE username = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int product_id = rs.getInt("product_id");
                int quantity = rs.getInt("quantity");

                // Handle possible null values
                double totalAmount = rs.getObject("totalAmount") != null ? rs.getDouble("totalAmount") : 0.0;
                int months = rs.getObject("months") != null ? rs.getInt("months") : 0;

                // Fetch product details
                String query2 = "SELECT * FROM products WHERE id = ?";
                PreparedStatement ps2 = con.prepareStatement(query2);
                ps2.setInt(1, product_id);
                ResultSet rs2 = ps2.executeQuery();

                if (rs2.next()) {
                    String productTitle = rs2.getString("title");
                    double originalRate = rs2.getBigDecimal("originalRate").doubleValue();

                    // Store data in a CSV-like format
                    String cartItem = username + "," + quantity + "," + totalAmount + "," + months + "," + productTitle + "," + originalRate;
                    cartItems.add(cartItem);
                }
                rs2.close();
                ps2.close();
            }

            rs.close();
            ps.close();
            con.close();

            request.setAttribute("cartItems", cartItems);
            request.getRequestDispatcher("cart.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
