import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddToCartServlet")
public class AddToCart extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int productId = Integer.parseInt(request.getParameter("productId"));
        int quantity = Integer.parseInt(request.getParameter("quantity")); 
        String totalAmount = request.getParameter("totalAmount");
        String months = request.getParameter("months");

        // Get user ID from session
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if (username == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        try {
            // Database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Instamart", "root", "om61,,..");

            // Check if product is in stock
            String checkQuery = "SELECT quantity FROM products WHERE id=?";
            PreparedStatement checkStmt = con.prepareStatement(checkQuery);
            checkStmt.setInt(1, productId);
            var rs = checkStmt.executeQuery();

            if (rs.next() && rs.getInt("quantity") > 0) {
                // Add product to cart
                String insertQuery = "INSERT INTO cart (username, product_id, quantity, totalAmount, months) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement insertStmt = con.prepareStatement(insertQuery);
                insertStmt.setString(1, username);
                insertStmt.setInt(2, productId);
                insertStmt.setInt(3, quantity);
                insertStmt.setString(4, totalAmount);
                insertStmt.setString(5, months);
                
                insertStmt.executeUpdate();

                // Decrease product quantity
                String updateQuery = "UPDATE products SET quantity = quantity - 1 WHERE id=?";
                PreparedStatement updateStmt = con.prepareStatement(updateQuery);
                updateStmt.setInt(1, productId);
                updateStmt.executeUpdate();

                response.sendRedirect("Cart"); // Redirect to cart page
            } else {
                response.getWriter().println("Product out of stock.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error adding to cart.");
        }
    }
}
