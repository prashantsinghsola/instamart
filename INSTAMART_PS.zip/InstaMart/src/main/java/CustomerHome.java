

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CustomerHome
 */


@WebServlet("/CustomerHome")
public class CustomerHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerHome() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		try {
            // Database Connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Instamart", "root", "om61,,..");

            // Retrieve products
            String query = "SELECT * FROM products";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            
            List<String> cartItem = new ArrayList<>();

            while (rs.next()) {
            	String str = rs.getInt("id")+","+rs.getString("title")+","+rs.getDouble("originalRate")+","+rs.getString("material")+","+rs.getString("brand")+","+rs.getString("dimensions")+","+rs.getString("productCategory")+","+rs.getInt("quantity")+","+rs.getString("imageUrl");
            	cartItem.add(str);
            	System.out.println(str);
            }
            
            for (String product : cartItem) {
            	System.out.println(product.split(",")[0]);
                System.out.println(product.split(",")[1]);
            }
            
            con.close();
            request.setAttribute("cartItemList", cartItem);
            request.getRequestDispatcher("CustomerHome.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
