package default_package;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EditProfile
 */
@WebServlet("/EditProfile")
public class EditProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    java.sql.Statement st;
    private static final String URL = "jdbc:mysql://localhost:3306/Instamart";
    private static final String USER = "root";
    private static final String PASSWORD = "om61,,..";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("index.jsp");  // Redirect to login if session expires
            return;
        }

        String username = (String) session.getAttribute("username");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
		
        
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection(URL,USER,PASSWORD);

            // SQL query to fetch user details
            String sql = "SELECT * FROM users WHERE username=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Set attributes to request
                request.setAttribute("username", rs.getString("username"));
                request.setAttribute("dob", rs.getString("dob"));
                request.setAttribute("age", rs.getInt("age"));
                request.setAttribute("contact", rs.getString("contact"));
                request.setAttribute("street", rs.getString("street"));
                request.setAttribute("city", rs.getString("city"));
                request.setAttribute("state", rs.getString("state"));
                request.setAttribute("country", rs.getString("country"));
                request.setAttribute("pinCode", rs.getString("pinCode"));

                // Forward to profile JSP page
                request.getRequestDispatcher("EditProfile.jsp").forward(request, response);
            } else {
                response.sendRedirect("Profile.jsp?error=1");  // Redirect if no user found
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("Profile.jsp?error=2");  // Redirect in case of error
        }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
