package default_package;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Signup
 */
@WebServlet("/Signup")
public class Signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
    Connection con;
    java.sql.Statement st;
    private static final String URL = "jdbc:mysql://localhost:3306/Instamart";
    private static final String USER = "root";
    private static final String PASSWORD = "om61,,..";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Signup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("SignUp.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String fullname = request.getParameter("fullname").toString();
		String email = request.getParameter("email").toString();
		String username = request.getParameter("username").toString();
		String password = request.getParameter("password").toString();
		
		
		try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Load JDBC Driver
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            if(con != null) {
            	System.out.println("Database Connected Successfully!");
            }
		}catch(Exception e) {
			System.out.println("Failed database connection!");
		}
            
            
            // start
		try {
		    // 1️⃣ Check if username or email already exists
		    String checkUserQuery = "SELECT COUNT(*) FROM users WHERE username = ? OR email = ?";
		    try (PreparedStatement checkStmt = con.prepareStatement(checkUserQuery)) {
		        checkStmt.setString(1, username);
		        checkStmt.setString(2, email);
		        ResultSet rs = checkStmt.executeQuery();
		        
		        if (rs.next()) {  // Move to first row
		            int count = rs.getInt(1);  // Get the first column
		            
		            if (count > 0) {  // If count > 0, user exists
		                System.out.println("User with this email/Username already exists!");
		                request.setAttribute("msg", "User with this Email/Username already exists!");
		                request.getRequestDispatcher("SignUp.jsp").forward(request, response);
		                return;  // Stop execution
		            }
		        }
		    }
		

		    // 2️⃣ Insert New User
		    String insertQuery = "INSERT INTO users(full_name, email, username, password) VALUES (?, ?, ?, ?)";
		    try (PreparedStatement insertStmt = con.prepareStatement(insertQuery)) {
		        insertStmt.setString(1, fullname);
		        insertStmt.setString(2, email);
		        insertStmt.setString(3, username);
		        insertStmt.setString(4, password);
		        insertStmt.executeUpdate();
		        System.out.println("Record Added Successfully");

		        request.setAttribute("username", username);

		        request.getRequestDispatcher("profileDetails.jsp").forward(request, response);
		    }
		} catch (SQLException e) {
		    System.out.println("Something went wrong!");
		    e.printStackTrace();
		}

	}
}
