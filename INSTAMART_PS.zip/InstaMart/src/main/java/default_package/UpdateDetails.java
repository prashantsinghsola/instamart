package default_package;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UpdateDetails
 */
@WebServlet("/UpdateDetails")
public class UpdateDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	Connection con;
    java.sql.Statement st;
    private static final String URL = "jdbc:mysql://localhost:3306/Instamart";
    private static final String USER = "root";
    private static final String PASSWORD = "om61,,..";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String username = request.getParameter("username");// from last page
		System.out.println(username+"exists");
		
		String dobString = request.getParameter("dob");
		int age = Integer.parseInt(request.getParameter("age"));
		String contactString = request.getParameter("contact");
		String streetString = request.getParameter("street");
		String cityString = request.getParameter("city");
		String stateString = request.getParameter("state");
		String countryString = request.getParameter("country");
		int pinCode = Integer.parseInt(request.getParameter("pinCode"));
		boolean userType = Boolean.parseBoolean(request.getParameter("userType"));
		
		java.sql.Date sqlDob = null;
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date utilDate = formatter.parse(dobString);
            sqlDob = new java.sql.Date(utilDate.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        // Database connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  // Load JDBC Driver
            con = DriverManager.getConnection(URL, USER, PASSWORD);
            if(con != null) {
            	System.out.println("Database Connected Successfully!");
            }
		}catch(Exception e) {
			System.out.println("Failed database connection!");
		}
        
        // operation
        try {
		    String insertionQuery = "UPDATE users SET dob=?, age=?, contact=?, street=?, city=?, country=?, pinCode=?, state=?, isAdmin=? WHERE username = ?";
		    
		    try (PreparedStatement pst  = con.prepareStatement(insertionQuery)) {
		    	pst.setDate(1, sqlDob);
		    	pst.setInt(2, age);
		        pst.setString(3, contactString);
		        pst.setString(4, streetString);
		        pst.setString(5, cityString);
		        pst.setString(6, countryString);
		        pst.setInt(7, pinCode);
		        pst.setString(8, stateString);
		        pst.setBoolean(9, userType);
		        
		        pst.setString(10, username);
		        
		        int rowsAffected = pst.executeUpdate(); // Check how many rows were updated
		        
		        if (rowsAffected > 0) {
		            request.setAttribute("msg", "Profile Updated Successfully! ☑");
		            request.getRequestDispatcher("index.jsp").forward(request, response);
		            System.out.println("Record Updated Successfully: " + rowsAffected + " row(s) affected.");
		        } else {
		            request.setAttribute("msg", "Update Failed! User not found.");
		            request.getRequestDispatcher("SignUp.jsp").forward(request, response);
		            System.out.println("No records updated. Possible reasons: invalid username or user does not exist.");
		        }
		    }
		} catch (SQLException e) {
		    	System.out.println("Something went wrong!");
		    	request.setAttribute("msg", "Update Failed! User not found.");
	            request.getRequestDispatcher("SignUp.jsp").forward(request, response);
		    	e.printStackTrace();
		}
	}
}
