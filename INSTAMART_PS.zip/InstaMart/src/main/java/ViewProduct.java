

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ViewProduct
 */
@WebServlet("/ViewProduct")
public class ViewProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
            // Database Connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Instamart", "root", "om61,,..");
            
            // Retrieve products
            int id = Integer.parseInt(request.getParameter("productId"));
            String query = "SELECT * FROM products WHERE id =?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            
            
            String str = "";
            while (rs.next()) {
            	str = rs.getInt("id")+","+rs.getString("title")+","+rs.getDouble("originalRate")+","+rs.getString("material")+","+rs.getString("brand")+","+rs.getString("dimensions")+","+rs.getString("productCategory")+","+rs.getInt("quantity")+","+rs.getString("imageUrl");
            	
            	System.out.println(str);
            }
            
            
            con.close();
            request.setAttribute("cartItem", str);
            response.sendRedirect("ViewProduct.jsp?cartItem=" + URLEncoder.encode(str, "UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}
